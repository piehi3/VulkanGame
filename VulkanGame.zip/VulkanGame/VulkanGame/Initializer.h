#include "BUILD_ORDER.h"

namespace Initializers {
	VkApplicationInfo ApplicationInfo(VulkanConfiguration config);

	VkInstanceCreateInfo InstanceCreateInfo(VkApplicationInfo& app_info, std::vector<const char*>& layers, std::vector<const char*>& extenstions);

	VkDeviceCreateInfo DeviceCreateInfo(std::vector<VkDeviceQueueCreateInfo>& queue_create_infos,VkPhysicalDeviceFeatures& physical_device_features);
	VkDeviceQueueCreateInfo DeviceQueueCreate(uint32_t queue_family_index, float& priority);

}