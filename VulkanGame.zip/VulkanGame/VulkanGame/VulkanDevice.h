#pragma once
#include "BUILD_ORDER.h"

class VulkanPhysicalDevice;

class VulkanDevice
{
public:
	VulkanDevice(VulkanInstance* instance, VulkanPhysicalDevice* physical_device);
	VulkanInstance* GetInstance();
	VkQueue* GetQueue();
	VkDevice* GetDevice();

	~VulkanDevice();
private:
	VulkanInstance* m_instance;
	VulkanPhysicalDevice* m_physical_device;
	VkDevice m_device;
	VkQueue m_compute_queue;
};

