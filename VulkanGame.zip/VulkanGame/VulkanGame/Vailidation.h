#pragma once
#include "BUILD_ORDER.h"

void ErrorCheck(VkResult res);