#include "Initializer.h"

VkApplicationInfo Initializers::ApplicationInfo(VulkanConfiguration config)
{

	VkApplicationInfo info = {};
	info.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
	info.pApplicationName = config.application_name;
	info.pEngineName = config.engine_name;
	info.engineVersion = config.application_version;
	info.apiVersion = config.api_version;


	return info;
}

VkInstanceCreateInfo Initializers::InstanceCreateInfo(VkApplicationInfo& app_info, std::vector<const char*>& layers, std::vector<const char*>& extenstions)
{
	VkInstanceCreateInfo info = {};

	info.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
	info.pApplicationInfo = &app_info;
	info.enabledExtensionCount = extenstions.size();
	info.enabledLayerCount = layers.size();
	info.ppEnabledExtensionNames = extenstions.data();
	info.ppEnabledLayerNames = layers.data();


	return info;
}

VkDeviceCreateInfo Initializers::DeviceCreateInfo(std::vector<VkDeviceQueueCreateInfo>& queue_create_infos, VkPhysicalDeviceFeatures & physical_device_features)
{
	VkDeviceCreateInfo create_info{};

	create_info.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
	create_info.pQueueCreateInfos = queue_create_infos.data();
	create_info.queueCreateInfoCount = (uint32_t)queue_create_infos.size();
	create_info.pEnabledFeatures = &physical_device_features;

	return create_info;
}

VkDeviceQueueCreateInfo Initializers::DeviceQueueCreate(uint32_t queue_family_index, float& priority)
{
	VkDeviceQueueCreateInfo queue_create_info{};
	queue_create_info.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
	queue_create_info.queueFamilyIndex = queue_family_index;
	queue_create_info.queueCount = 1;
	queue_create_info.pQueuePriorities = &priority;

	return queue_create_info;
}
