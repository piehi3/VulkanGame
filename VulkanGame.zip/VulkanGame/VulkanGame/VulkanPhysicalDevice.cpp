#include "VulkanPhysicalDevice.h"



VulkanPhysicalDevice::VulkanPhysicalDevice(VulkanInstance* instance, VkPhysicalDevice device, QueueFamilyIndices family_indecies)
{
	m_instance = instance;
	m_device = device;
	m_family_indices = family_indecies;

	vkGetPhysicalDeviceProperties(m_device,&m_physical_device_properties);
	vkGetPhysicalDeviceFeatures(m_device,&m_physical_device_features);
	vkGetPhysicalDeviceMemoryProperties(m_device,&m_physical_device_memory_properties);
}

std::vector<VkPhysicalDevice> VulkanPhysicalDevice::GetAvailablePhysicalDevices(VulkanInstance * instance)
{
	uint32_t device_count = 0;
	vkEnumeratePhysicalDevices(instance->GetInstance(), &device_count, nullptr);
	
	std::vector<VkPhysicalDevice> devices(device_count);
	vkEnumeratePhysicalDevices(instance->GetInstance(), &device_count, devices.data());

	return devices;
}


VulkanPhysicalDevice::~VulkanPhysicalDevice()
{
}

VkPhysicalDevice & VulkanPhysicalDevice::GetPhyscialDevice()
{
	return m_device;
}

QueueFamilyIndices & VulkanPhysicalDevice::GetQueueFamilyIndices()
{
	return m_family_indices;
}

VkPhysicalDeviceProperties & VulkanPhysicalDevice::GetPhysicalDeviceProperties()
{
	return m_physical_device_properties;
}

VkPhysicalDeviceFeatures & VulkanPhysicalDevice::GetPhysicalDeviceFeatures()
{
	return m_physical_device_features;
}

bool VulkanPhysicalDevice::PhysicalDeviceSupported(VkPhysicalDevice* device, QueueFamilyIndices* family_indecies) {
	bool supportsQueueFamily = SupportsQueueFamily(device, family_indecies);
	
	return supportsQueueFamily;
}

bool VulkanPhysicalDevice::SupportsQueueFamily(VkPhysicalDevice * device, QueueFamilyIndices * family_indecies)
{
	uint32_t queue_family_count = 0;
	vkGetPhysicalDeviceQueueFamilyProperties(*device,&queue_family_count,nullptr);

	std::vector<VkQueueFamilyProperties> queue_family_properties(queue_family_count);

	vkGetPhysicalDeviceQueueFamilyProperties(*device, &queue_family_count, queue_family_properties.data());
	uint32_t i = 0;
	for (VkQueueFamilyProperties& queue_family : queue_family_properties) {
		if (queue_family.queueCount > 0) {
			if (queue_family.queueFlags & VK_QUEUE_GRAPHICS_BIT)
				family_indecies->graphics_indices = i;
			if (queue_family.queueFlags & VK_QUEUE_COMPUTE_BIT)
				family_indecies->compute_indices = i;
		}
		if (family_indecies->graphics_indices < UINT32_MAX && family_indecies->compute_indices < UINT32_MAX) return true;
		i++;
	}

	return false;
}

VkPhysicalDeviceMemoryProperties & VulkanPhysicalDevice::GetPhysicalDeviceMemoryProperties()
{
	return m_physical_device_memory_properties;
}

VulkanPhysicalDevice* VulkanPhysicalDevice::GetPhysicalDevice(VulkanInstance * instance)
{
	std::vector<VkPhysicalDevice> devices = GetAvailablePhysicalDevices(instance);

	VkPhysicalDevice secondary_device = VK_NULL_HANDLE;
	QueueFamilyIndices secondery_queue;

	for (VkPhysicalDevice& device : devices) {
		QueueFamilyIndices queue_family;
		if (PhysicalDeviceSupported(&device, &queue_family)) {
			VkPhysicalDeviceProperties physical_device_properities;
			vkGetPhysicalDeviceProperties(device, &physical_device_properities);
			if (physical_device_properities.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU) {
				return new VulkanPhysicalDevice(instance,device, queue_family);
			}
			else {
				secondary_device = device;
				secondery_queue = queue_family;
			}
		}
	}
	if (secondary_device == VK_NULL_HANDLE) return nullptr;
	return new VulkanPhysicalDevice(instance,secondary_device, secondery_queue);
}
