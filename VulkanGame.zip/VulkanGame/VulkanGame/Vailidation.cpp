#include "Vailidation.h"

void ErrorCheck(VkResult res)
{
	if (res != VK_SUCCESS) {
		std::cout << "Error" << std::endl;
		assert(0&&"there was an error");
	}
}
