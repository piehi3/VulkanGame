#include "VulkanDevice.h"



VulkanDevice::VulkanDevice(VulkanInstance * instance, VulkanPhysicalDevice* physical_device)
{
	m_instance = instance;
	m_physical_device = physical_device;

	std::vector<VkDeviceQueueCreateInfo> queue_create_infos;
	float priority = 1.0f;
	queue_create_infos.push_back(Initializers::DeviceQueueCreate(m_physical_device->GetQueueFamilyIndices().compute_indices, priority));

	VkDeviceCreateInfo create_info = Initializers::DeviceCreateInfo(queue_create_infos,m_physical_device->GetPhysicalDeviceFeatures());

	ErrorCheck(vkCreateDevice(m_physical_device->GetPhyscialDevice(), &create_info, nullptr, &m_device));

	vkGetDeviceQueue(m_device,m_physical_device->GetQueueFamilyIndices().compute_indices,0,&m_compute_queue);

}

VulkanInstance * VulkanDevice::GetInstance()
{
	return m_instance;
}

VkQueue* VulkanDevice::GetQueue()
{
	return &m_compute_queue;
}

VkDevice* VulkanDevice::GetDevice()
{
	return &m_device;
}

VulkanDevice::~VulkanDevice()
{
	vkDestroyDevice(m_device, nullptr);
}
