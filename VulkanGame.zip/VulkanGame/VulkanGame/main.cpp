#include "BUILD_ORDER.h"

VulkanInstance* instance;
VulkanPhysicalDevice* physical_device;
VulkanDevice* device;

int main() {
	VulkanConfiguration vulkan_config;
	vulkan_config.application_name = "test app";
	vulkan_config.application_version = VK_MAKE_VERSION(1, 1, 1);

	instance = new VulkanInstance(vulkan_config);
	physical_device = VulkanPhysicalDevice::GetPhysicalDevice(instance);
	device = new VulkanDevice(instance, physical_device);

	delete device;
	delete physical_device;
	delete instance;

	return 0;
}